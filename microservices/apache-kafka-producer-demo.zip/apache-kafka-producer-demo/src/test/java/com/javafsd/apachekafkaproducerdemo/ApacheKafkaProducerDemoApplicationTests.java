package com.javafsd.apachekafkaproducerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApacheKafkaProducerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
